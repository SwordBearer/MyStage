<?php
return array(
	'imageSavePath'=>'../../image/blogimg/',
	'imageManagerPath'=>'../../image/blogimg/',
	'fileSavePath'=>'../../file',
	'catcherSavePath'=>'../../image/blogimg/'
);
?>