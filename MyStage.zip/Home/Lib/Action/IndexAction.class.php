<?php
class IndexAction extends Action {
    public function index(){
    	$this->redirect("__GROUP__/Blog/index");
	}
}