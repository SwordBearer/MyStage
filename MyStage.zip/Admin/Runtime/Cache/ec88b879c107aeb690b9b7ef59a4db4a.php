<?php if (!defined('THINK_PATH')) exit();?> <!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="author" content="xmu.SwordBearer">
	<link href="__PUBLIC__/admin/css/bootstrap.min.css" rel="stylesheet" />
 	<link href="__PUBLIC__/admin/css/mystage_admin.css" rel="stylesheet"/>
  	<script src="__PUBLIC__/admin/js/jquery-1.9.1.js" type="text/javascript" ></script>
  	<script src="__PUBLIC__/admin/js/bootstrap.min.js" type="text/javascript"></script>
</head>
 <body>
<!-- Navbar ================================= -->
<div class="navbar navbar-fixed-top navbar-inverse">
  <div class="navbar-inner">
    <div class="container">
      <a class="brand" href="">SwordBearer</a>
      <ul class="nav">
        <li>
          <a href="__GROUP__/Blog/index">个人博客</a>
        </li>
        <li>
          <a href="__GROUP__/Enshrine/index">美文网摘</a>
        </li>
        <li>
          <a href="__GROUP__/Ads/index">广告管理</a>
        </li>
        <li class="active">
          <a href="__GROUP__/Public/about">关于</a>
        </li>
      </ul>
    </div>
  </div>
</div>
 </body>
 </html>