<?php
Class AdminModel extends Model{
}
?>