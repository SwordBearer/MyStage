<?php
class EnshrineAction extends Action {
	/*****************pages*****************/
	public function index(){
		$this->display();
	}
}
?>