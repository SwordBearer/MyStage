<?php
class AdsAction extends Action {
	/*****************pages*****************/
	public function index(){
		$this->display();
	}
}
?>