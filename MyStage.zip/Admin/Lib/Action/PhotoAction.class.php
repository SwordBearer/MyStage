<?php
class PhotoAction extends Action {
	/*****************pages*****************/
	public function index(){
		$this->display();
	}
}
?>