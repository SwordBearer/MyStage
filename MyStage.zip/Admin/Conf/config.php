<?php
return array( 
	'URL_CASE_INSENSITIVE'  => true, 
	'CACHE_ADMIN'=>'./Admin/Runtime/',
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'127.0.0.1',
	'DB_USER'=>'root',
	'DB_PWD'=>'',
	'DB_NAME'=>'mystage',
	'DB_PREFIX'=>'mystage_',
);
?>