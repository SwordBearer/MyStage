<?php

define('APP_DEBUG',true);
define('APP_NAME', 'MyStage');
define('APP_PATH', './MyStage/');
define('THINK_PATH','./ThinkPHP/');
define('ENGINE_NAME','cluster');
require THINK_PATH.'ThinkPHP.php';
?>
