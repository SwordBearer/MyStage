<?php
define('APP_DEBUG',true);
define('APP_NAME', 'Home');
define('APP_PATH', './Home/');
define('THINK_PATH','./ThinkPHP/');
define('ENGINE_NAME','cluster');
require THINK_PATH.'/ThinkPHP.php';
?>