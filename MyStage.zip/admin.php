<?php
define('APP_DEBUG',true);
define('APP_NAME', 'Admin');
define('APP_PATH', './Admin/');
define('THINK_PATH','./ThinkPHP/');
define('ENGINE_NAME','cluster');
require THINK_PATH.'/ThinkPHP.php';
?>